import React from 'react';
import WithLayoutpages from 'hoc/WithLayoutPages';

const Home = () => {
    return (
        <div>
            Home
        </div>
    );
}

export default WithLayoutpages(Home);
