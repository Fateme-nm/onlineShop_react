import React from 'react';

const Slider = () => {
    return (
        <div>
            Slider
        </div>
    );
}

export default Slider;
