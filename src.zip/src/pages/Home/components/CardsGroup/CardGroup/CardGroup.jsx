import React from 'react';

const CardGroup = () => {
    return (
        <div>
            CardGroup
        </div>
    );
}

export default CardGroup;
