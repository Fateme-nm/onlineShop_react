import React from 'react';

const CardsGroup = () => {
    return (
        <div>
            CardsGroup
        </div>
    );
}

export default CardsGroup;
