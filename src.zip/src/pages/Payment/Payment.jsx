import React from 'react';
import WithLayoutpages from 'hoc/WithLayoutPages';

const Payment = () => {
    return (
        <div>
            Payment
        </div>
    );
}

export default WithLayoutpages(Payment);
