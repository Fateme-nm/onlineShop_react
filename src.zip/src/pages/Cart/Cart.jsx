import React from 'react';
import WithLayoutpages from 'hoc/WithLayoutPages';

const Cart = () => {
    return (
        <div>
            Cart
        </div>
    );
}

export default WithLayoutpages(Cart);
