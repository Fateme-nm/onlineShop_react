import React from 'react';
import WithLayoutpages from 'hoc/WithLayoutPages';

const Productslist = () => {
    return (
        <div>
            ProductsList
        </div>
    );
}

export default WithLayoutpages(Productslist);
