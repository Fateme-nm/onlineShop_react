import React from 'react';

const Comments = () => {
    return (
        <div>
            Comments
        </div>
    );
}

export default Comments;
