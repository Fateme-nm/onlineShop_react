import React from 'react';

const Gallerymodal = () => {
    return (
        <div>
            GalleryModal
        </div>
    );
}

export default Gallerymodal;
