import React from 'react';

const Similarproduct = () => {
    return (
        <div>
            SimilarProduct
        </div>
    );
}

export default Similarproduct;
