import React from 'react';

const Similarproducts = () => {
    return (
        <div>
            SimilarProducts
        </div>
    );
}

export default Similarproducts;
