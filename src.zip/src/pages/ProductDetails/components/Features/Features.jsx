import React from 'react';

const Features = () => {
    return (
        <div>
            Features
        </div>
    );
}

export default Features;
