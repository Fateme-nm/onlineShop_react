import React from 'react';

const Orderdetails = () => {
    return (
        <div>
            OrderDetails
        </div>
    );
}

export default Orderdetails;
