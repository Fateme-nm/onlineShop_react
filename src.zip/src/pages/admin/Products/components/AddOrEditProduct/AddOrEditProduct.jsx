import React from 'react';

const Addoreditproduct = () => {
    return (
        <div>
            AddOrEditProduct
        </div>
    );
}

export default Addoreditproduct;
