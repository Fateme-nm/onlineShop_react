import React from 'react';
import WithLayoutpages from 'hoc/WithLayoutPages';

const Notfound = () => {
    return (
        <div>
            Notfound
        </div>
    );
}

export default WithLayoutpages(Notfound);
