import React from 'react';
import WithLayoutpages from 'hoc/WithLayoutPages';

const Paymentresult = () => {
    return (
        <div>
            PaymentResult
        </div>
    );
}

export default WithLayoutpages(Paymentresult);
