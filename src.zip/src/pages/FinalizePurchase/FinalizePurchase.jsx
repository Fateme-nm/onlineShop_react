import React from 'react';
import WithLayoutpages from 'hoc/WithLayoutPages';

const Finalizepurchase = () => {
    return (
        <div>
            FinalizePurchase
        </div>
    );
}

export default WithLayoutpages(Finalizepurchase);
