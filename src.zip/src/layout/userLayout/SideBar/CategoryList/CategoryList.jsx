import React from 'react';

const Categorylist = () => {
    return (
        <div>
            CategoryList
        </div>
    );
}

export default Categorylist;
