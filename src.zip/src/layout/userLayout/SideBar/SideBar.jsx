import React from 'react';

const Sidebar = () => {
    return (
        <aside>
            SideBar
        </aside>
    );
}

export default Sidebar;
