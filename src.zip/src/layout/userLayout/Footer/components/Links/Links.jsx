import React from 'react';

const Links = () => {
    return (
        <div>
            Links
        </div>
    );
}

export default Links;
