import React from 'react';

const Categorieslist = () => {
    return (
        <div>
            CategoriesList
        </div>
    );
}

export default Categorieslist;
