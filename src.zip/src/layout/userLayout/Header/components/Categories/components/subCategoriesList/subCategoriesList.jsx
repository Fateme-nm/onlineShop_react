import React from 'react';

const Subcategorieslist = () => {
    return (
        <div>
            subCategoriesList
        </div>
    );
}

export default Subcategorieslist;
