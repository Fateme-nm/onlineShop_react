import React from 'react';

const Cartitems = () => {
    return (
        <div>
            CartItems
        </div>
    );
}

export default Cartitems;
