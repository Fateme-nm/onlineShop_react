import React from 'react';

const Cartitem = () => {
    return (
        <div>
            CartItem
        </div>
    );
}

export default Cartitem;
