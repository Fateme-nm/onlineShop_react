import React from 'react';

const Option = () => {
    return (
        <div>
            Options
        </div>
    );
}

export default Option;
